<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Result_searchModleAdmin
 *
 * @author Binita
 */
class Result_searchModleAdmin {
    //put your code here
}

?>
