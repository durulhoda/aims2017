<div class="page-content">
    <!-- /Content Section  -->  
    <div style="margin-top: 20px; padding: 3.5px;">                   
        <div class="page-header">
    <h1>
        Institute Account System
        <small>
            <i class="ace-icon fa fa-angle-double-right"></i>
            Dashboard 
        </small>
    </h1>
</div><!-- /.page-header -->

<div class="row">
    <div class="col-xs-12">
        <!-- PAGE CONTENT BEGINS -->
        <div class="alert alert-block alert-success">

            <i class="ace-icon fa fa-check green"></i>

          
            <strong class="red">
                Welcome Back Accounts Admin.
            </strong>
            
        </div>

        <div class="row">
            <div class="space-6"></div>

     
            
        
     

            
            
        </div> <!-- /.row -->

    </div><!-- /.col-x12 -->
</div> 
</div>
    </div>
</div>